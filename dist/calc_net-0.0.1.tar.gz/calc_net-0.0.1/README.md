# calc_net
Calculate net weight of fruit cargo.
