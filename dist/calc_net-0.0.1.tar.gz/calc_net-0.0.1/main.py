from src.calc_net import main_gui

if __name__=="__main__":
    main_gui()