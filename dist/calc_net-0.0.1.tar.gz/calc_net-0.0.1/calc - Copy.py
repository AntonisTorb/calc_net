import tkinter as tk
from tkinter import ttk




class Calc:


    def reset(self):
        
        self.entry_gross.delete(0,tk.END)
        self.entry_gross.insert(0,"0")
        self.entry_bins.delete(0,tk.END)
        self.entry_bins.insert(0,"0")
        self.entry_kl.delete(0,tk.END)
        self.entry_kl.insert(0,"0")
        self.label_mat_val.config(text="0")
        self.label_fyr_val.config(text="0")
        self.label_net_val.config(text="0")


    def exit(self):

        self.looping = False


    def calculate(self):

        self.gross_value = self.entry_gross.get()
        self.bins = self.entry_bins.get()
        self.kl = self.entry_kl.get()

        try:
            bins_mass = 30 * int(self.bins)
            kl_mass = 2 * int(self.kl)
            mat_mass = bins_mass + kl_mass
            self.label_mat_val.config(text=str(mat_mass))

            mid_mass = float(self.gross_value) - mat_mass

            fyr = 0.05 * mid_mass
            self.label_fyr_val.config(text=str(round(fyr, 2)))

            net_mass = mid_mass - fyr
            self.label_net_val.config(text=str(net_mass))

        except ValueError:
            self.label_mat_val.config(text="ERROR")
            self.label_fyr_val.config(text="ERROR")
            self.label_net_val.config(text="ERROR")


    def main_gui(self):

        self.root = tk.Tk()
        self.root.configure(background="lightblue")
        self.root.geometry("800x600")
        self.root.title("ΥΠΟΛΟΓΙΣΜΟΣ ΚΑΘΑΡΟΥ ΒΑΡΟΥΣ")

        self.frame = tk.Frame(self.root)
        self.frame.configure(background="lightblue")
        self.frame.columnconfigure(0, weight=1)
        self.frame.columnconfigure(1, weight=1)
        self.frame.columnconfigure(2, weight=1)

        self.label_gross = tk.Label(self.frame, text="ΜΙΚΤΟ ΒΑΡΟΣ:", font=("Arial", 20), anchor="w")
        self.label_gross.configure(background="lightblue")
        self.label_gross.grid(row=0, column=0, sticky=(tk.W, tk.E), padx=20, pady=20)
        self.entry_gross = tk.Entry(self.frame, font=("Arial", 20))
        self.entry_gross.insert(1, "0")
        self.entry_gross.grid(row=0, column=1, sticky=(tk.W, tk.E), padx=20, pady=20, columnspan=3)

        self.label_bins = tk.Label(self.frame, text="BINS (30KG):", font=("Arial", 20), anchor="w")
        self.label_bins.configure(background="lightblue")
        self.label_bins.grid(row=1, column=0, sticky=(tk.W, tk.E), padx=20, pady=20)
        self.entry_bins = tk.Entry(self.frame, font=("Arial", 20))
        self.entry_bins.insert(1, "0")
        self.entry_bins.grid(row=1, column=1, sticky=(tk.W, tk.E), padx=20, pady=20, columnspan=3)

        self.label_kl = tk.Label(self.frame, text="ΚΛΟΥΒΕΣ (2KG):", font=("Arial", 20), anchor="w")
        self.label_kl.configure(background="lightblue")
        self.label_kl.grid(row=2, column=0, sticky=(tk.W, tk.E), padx=20, pady=20)
        self.entry_kl = tk.Entry(self.frame, font=("Arial", 20))
        self.entry_kl.insert(1, "0")
        self.entry_kl.grid(row=2, column=1, sticky=(tk.W, tk.E), padx=20, pady=20, columnspan=3)

        self.seperator_1 = ttk.Separator(self.frame, orient="horizontal")
        self.seperator_1.grid(row=3, column=0, sticky=(tk.W, tk.E), columnspan=3)

        self.label_mat = tk.Label(self.frame, text="BΑΡΟΣ ΥΛΙΚΟΥ:", font=("Arial", 20), wraplength=120)
        self.label_mat.configure(background="lightblue")
        self.label_mat.grid(row=4, column=0, sticky=(tk.W, tk.E), padx=20)
        self.label_fyr = tk.Label(self.frame, text="BΑΡΟΣ ΑΠΟΜΕΙΩΣΗΣ / ΦΥΡΑ:", font=("Arial", 20), wraplength=200)
        self.label_fyr.configure(background="lightblue")
        self.label_fyr.grid(row=4, column=1, sticky=(tk.W, tk.E), padx=20)
        self.label_net = tk.Label(self.frame, text="ΚΑΘΑΡΟ ΒΑΡΟΣ:", font=("Arial", 20, "bold"), wraplength=200, background="limegreen")
        self.label_net.configure(background="lightblue")
        self.label_net.grid(row=4, column=2, sticky=(tk.W, tk.E), padx=20)

        self.label_mat_val = tk.Label(self.frame, text="0", font=("Arial", 20))
        self.label_mat_val.grid(row=5, column=0, sticky=(tk.W, tk.E), padx=20)
        self.label_fyr_val = tk.Label(self.frame, text="0", font=("Arial", 20))
        self.label_fyr_val.grid(row=5, column=1, sticky=(tk.W, tk.E), padx=20)
        self.label_net_val = tk.Label(self.frame, text="0", font=("Arial", 20, "bold"), background="limegreen")
        self.label_net_val.grid(row=5, column=2, sticky=(tk.W, tk.E), padx=20)

        self.seperator_2 = ttk.Separator(self.frame, orient="horizontal")
        self.seperator_2.grid(row=6, column=0, sticky=(tk.W, tk.E), columnspan=3, pady=20)

        self.reset_btn = tk.Button(self.frame, text="EXIT", font=("Arial", 20, "bold"), background="red", command=self.exit)
        self.reset_btn.grid(row=7, column=0)
        self.calc_btn = tk.Button(self.frame, text="RESET", font=("Arial", 20, "bold"), background="orange", command=self.reset)
        self.calc_btn.grid(row=7, column=2, columnspan=2)
        
        self.frame.pack(fill="both")

        self.looping = True
        try:
            while self.looping:
                self.calculate()
                self.root.update()
        except tk.TclError:
            return


def main_gui():
    calc = Calc()
    calc.main_gui()
